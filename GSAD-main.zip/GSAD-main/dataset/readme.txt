You can refer to the corresponding links to download the LOLv1 and LOLv2 datasets and put it in this folder.
