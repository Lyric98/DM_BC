You can refer to the corresponding link to download the [LOL](https://daooshee.github.io/BMVC2018website/) dataset and put it in this folder.
